let compteur = 0
while(compteur < 3){
  console.log(compteur)
  compteur++

}
